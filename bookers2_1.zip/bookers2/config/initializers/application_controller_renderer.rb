# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '30c25cb0757e6dcd9218725f6826f6fb6512810a9dc879da28ba63c984f3dc05898389eedfbb2638ddeeda90feb7eb9ef8a2c2a3038b5001fa5c4d45eb88fa62'
